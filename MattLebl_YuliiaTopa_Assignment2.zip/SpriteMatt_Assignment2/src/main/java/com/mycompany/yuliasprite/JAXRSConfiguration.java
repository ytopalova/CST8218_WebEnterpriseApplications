/*
 *Author:   Yuliia Topalova - 040981104 | Matthew LeBlanc - 040961708
 *Project:  Assignment 2
 *Class:    JAXRSConfigurations
 *Purpose:  Configures JAX-RS for the application.
 */

package com.mycompany.yuliasprite;

import javax.enterprise.context.ApplicationScoped;
import javax.inject.Named;
import javax.security.enterprise.authentication.mechanism.http.BasicAuthenticationMechanismDefinition;
import javax.security.enterprise.identitystore.DatabaseIdentityStoreDefinition;
import javax.security.enterprise.identitystore.PasswordHash;
import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 * @author Juneau
*/

/*
    Edit the database configuration
*/
@DatabaseIdentityStoreDefinition(
   dataSourceLookup = "${'java:app/Assignment2'}",
   callerQuery = "#{'select password from appuser where userid = ?'}",
   groupsQuery = "select groupname from appuser where userid = ?",
   hashAlgorithm = PasswordHash.class,
   priority = 10
)

@BasicAuthenticationMechanismDefinition
@ApplicationScoped
@Named

@ApplicationPath("resources")
public class JAXRSConfiguration extends Application {
    
}
