/*
 *Author:   Yuliia Topalova - 040981104 | Matthew LeBlanc - 040961708
 *Project:  Assignment 2
 *Class:    SpriteTest
 *Purpose:  This class tests the functions of the Sprite class for functionality
 */
package TestPackage;

import cst8218.topa0005.entity.Sprite;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class SpriteTest {
    
    public SpriteTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }
    
    /*
        Method for testing the move function
    */
    @Test
    public void testMove() {
        Sprite gameSprite = new Sprite();
        gameSprite.setxSpeed(5); gameSprite.setySpeed(5); gameSprite.setX(0); gameSprite.setY(0);
        
        gameSprite.move();
        
        int total = gameSprite.getX() + gameSprite.getY();
        
        assertEquals(10, total);
    }
    
    /*
        Method for testing the move function
    */
    @Test
    public void testBounceLeft() {
        Sprite gameSprite = new Sprite();
        gameSprite.setxSpeed(5);
        
        int referenceSpeed = gameSprite.getxSpeed();
        
        gameSprite.bounceLeftWall();
        
        assertNotEquals(referenceSpeed, gameSprite.getxSpeed());
    }
    
    /*
        Method for testing the bounce right function
    */
    @Test
    public void testBounceRight() {
        Sprite gameSprite = new Sprite();
        gameSprite.setxSpeed(5);
        
        int referenceSpeed = gameSprite.getxSpeed();
        
        gameSprite.bounceRightWall();
        
        assertNotEquals(referenceSpeed, gameSprite.getxSpeed());
    }
    
    /*
        Method for testing the bounce up function
    */
    @Test
    public void testBounceUp() {
        Sprite gameSprite = new Sprite();
        gameSprite.setySpeed(5);
        
        int referenceSpeed = gameSprite.getySpeed();
        
        gameSprite.bounceTopWall();
        
        assertNotEquals(referenceSpeed, gameSprite.getySpeed());
    }
    
    /*
        Method for testing the bounce down function
    */
    @Test
    public void testBounceDown() {
        Sprite gameSprite = new Sprite();
        gameSprite.setySpeed(5);
        
        int referenceSpeed = gameSprite.getySpeed();
        
        gameSprite.bounceBottomWall();
        
        assertNotEquals(referenceSpeed, gameSprite.getySpeed());
    }
}
